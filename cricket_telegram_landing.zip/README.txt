# Cricket Telegram Landing Page

Telegram button link:
https://t.me/+Ptx9ZeofGk02N2U1

## Live on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` and `style.css`.
3. Open the repository's **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/root`, then save.
5. GitHub will provide your live website URL.

The Telegram link is already connected to every Join Channel button.
